<?php
$conn = mysqli_connect("localhost","examen","123456");
mysqli_select_db($conn, "academico");
?>